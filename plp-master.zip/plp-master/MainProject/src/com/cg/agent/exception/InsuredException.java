package com.cg.agent.exception;

public class InsuredException extends Exception{
	public InsuredException(String name)
	{
		super(name);
	}
}
